<?php $__env->startSection('title', '| Login'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <?php echo Form::open(); ?>


        <?php echo e(Form::label('email', 'Email:')); ?>

        <?php echo e(Form::email('email', null, array('class' => 'form-control'))); ?>


        <?php echo e(Form::label('password', 'Password:')); ?>

        <?php echo e(Form::password('password', array('class' => 'form-control'))); ?>


        <br>
        <?php echo e(Form::checkbox('remember')); ?> <?php echo e(Form::label('remember', 'Remember Me')); ?>


        <div class="row btn-h2-spacing">
          <div class="col-sm-6">
        <?php echo e(Form::submit('Login', array('class' => 'btn btn-warning btn-block'))); ?>

        <?php echo Form::close(); ?>

          </div>

          <div class="col-sm-6">
        <a href="<?php echo e(route('register')); ?>" class="btn btn-primary btn-block">Sign Up</a>
          </div>

    </div>
    <p><a href="<?php echo e(url('password/reset')); ?>" class="btn btn-link btn-h2-spacing">Forgot Password</a></p>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
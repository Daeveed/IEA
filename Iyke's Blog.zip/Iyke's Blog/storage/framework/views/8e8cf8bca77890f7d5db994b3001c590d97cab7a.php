<h3>You have a new contact via the Contact Form</h3>

<div>
  <?php echo e($bodyMessage); ?>

</div>

<p>Sent Via <?php echo e($email); ?></p>

<?php $__env->startSection('title', '| Edit Tag'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo Form::model($tag, array('route' => array('tags.update', $tag->id), 'method' => 'PUT')); ?>


    <?php echo e(Form::label('name', "Title:")); ?>

    <?php echo e(Form::text('name', null, array('class' => 'form-control'))); ?>


    <div class="row">
      <div class="col-md-3">
        <?php echo e(Form::submit('Save Changes', array('class' => 'btn btn-success btn-h1-spacing btn-block'))); ?>

      </div>

      <div class="col-md-3">
        <a href="<?php echo e(url('/tags')); ?>" class="btn btn-danger btn-h1-spacing btn-block">Cancel</a>
      </div>
    </div>

  <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
@extends('main')

@section('title', '| Create New Post')

@section('styleshets')

	{!! Html::style('css/parsley.css') !!}
	{!! Html::style('css/select2.min.css') !!}

@endsection

@section('content')

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h1>Create New Post</h1>
			<hr>

			{!! Form::open(['route' => 'posts.store', 'data-parsley-validate' => '', 'files' => true]) !!}
    			{{ Form::label('title', 'Title:') }}
    			{{ Form::text('title', null, array('class' => 'form-control', 'required' => '', 'max-length' => '255')) }}

					{{ Form::label('slug', 'Slug:', array('class' => 'btn-h3-spacing')) }}
					{{ Form::text('slug', null, array('class' => 'form-control', 'required' => '', 'minlength' => '5', 'maxlength' => '255')) }}

					{{ Form::label('category_id', 'Category:', array('class' => 'btn-h3-spacing')) }}
					<select class="form-control" name="category_id">
						@foreach($categories as $category)
							<option value='{{ $category->id }}'>{{ $category->name }}</option>
						@endforeach

					</select>

					{{ Form::label('tags', 'Tags:', array('class' => 'btn-h3-spacing')) }}
						<select name="tags[]" class="js-example-basic-multiple form-control" multiple="multiple">
							@foreach ($tags as $tag)
								<option value='{{ $tag->id }}'>{{ $tag->name }}</option>
							@endforeach

						</select>

					{{ Form::label('featured_image', 'Upload Featured Image:', array('class' => 'btn-h3-spacing')) }}
					{{ Form::file('featured_image') }}


    			{{ Form::label('body', 'Create Body:', array('class' => 'btn-h3-spacing')) }}
    			{{ Form::textarea('body', null, array('class' => 'form-control', 'required' => '', 'id' => 'technig')) }}

    			{{ Form::submit('Create Post', array('class' => 'btn btn-success btn-lg', 'style' => 'margin-top: 20px;')) }}

			{!! Form::close() !!}
		</div>
	</div>

@endsection

@section('scripts')

	{!! Html::script('js/parsley.min.js') !!}
	{!! Html::script('js/select2.min.js') !!}

@endsection

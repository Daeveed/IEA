@extends('main')

@section('title', '| Login')

@section('content')

  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      {!! Form::open() !!}

        {{ Form::label('email', 'Email:') }}
        {{ Form::email('email', null, array('class' => 'form-control')) }}

        {{ Form::label('password', 'Password:') }}
        {{ Form::password('password', array('class' => 'form-control')) }}

        <br>
        {{ Form::checkbox('remember') }} {{ Form::label('remember', 'Remember Me') }}

        <div class="row btn-h2-spacing">
          <div class="col-sm-6">
        {{ Form::submit('Login', array('class' => 'btn btn-warning btn-block')) }}
        {!! Form::close() !!}
          </div>

          <div class="col-sm-6">
        <a href="{{ route('register') }}" class="btn btn-primary btn-block">Sign Up</a>
          </div>

    </div>
    <p><a href="{{ url('password/reset') }}" class="btn btn-link btn-h2-spacing">Forgot Password</a></p>
  </div>
</div>

@endsection

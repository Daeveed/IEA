<h3>You have a new contact via the Contact Form</h3>

<div>
  {{ $bodyMessage }}
</div>

<p>Sent Via {{ $email }}</p>

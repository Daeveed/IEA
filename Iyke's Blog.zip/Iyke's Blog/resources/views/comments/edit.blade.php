@extends('main')

@section('title', '| Edit Comment')

@section('content')

<div class="row">
  <div class="col-md-8 col-md-offset-2">

      <h1>Edit Comment</h1>

        {{ Form::model($comment, array('route' => array('comments.update', $comment->id), 'method' => 'PUT')) }}

        {{ Form::label('name', 'Name:', array('class' => 'btn-h2-spacing')) }}
        {{ Form::text('name', null, array('class' => 'form-control', 'disabled' => '')) }}

        {{ Form::label('email', 'Email:', array('class' => 'btn-h2-spacing')) }}
        {{ Form::text('email', null, array('class' => 'form-control', 'disabled' => '')) }}

        {{ Form::label('commnt', 'Comment:', array('class' => 'btn-h2-spacing')) }}
        {{ Form::textarea('comment', null, array('class' => 'form-control')) }}

        <div class="row">
          <div class="col-md-4">
            {{ Form::submit('Update Comment', array('class' => 'btn btn-success btn-block btn-h2-spacing')) }}
          </div>

          <div class="col-md-4">
            <a href="{{ url('/posts', $comment->post->id) }}" class="btn btn-h2-spacing btn-danger btn-block">Cancel</a>
          </div>
      {{ Form::close() }}
    </div>
  </div>
</div>

@endsection

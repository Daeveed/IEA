@extends('main')

@section('title', '| Edit Tag')

@section('content')

  {!! Form::model($tag, array('route' => array('tags.update', $tag->id), 'method' => 'PUT')) !!}

    {{ Form::label('name', "Title:") }}
    {{ Form::text('name', null, array('class' => 'form-control')) }}

    <div class="row">
      <div class="col-md-3">
        {{ Form::submit('Save Changes', array('class' => 'btn btn-success btn-h1-spacing btn-block')) }}
      </div>

      <div class="col-md-3">
        <a href="{{ url('/tags') }}" class="btn btn-danger btn-h1-spacing btn-block">Cancel</a>
      </div>
    </div>

  {!! Form::close() !!}

@endsection

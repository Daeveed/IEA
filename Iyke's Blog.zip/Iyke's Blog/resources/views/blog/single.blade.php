@extends('main')
<?php $titleTag = htmlspecialchars($post->title); ?>
@section('title', "| $titleTag")

@section('content')

  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <img src="{{ asset('images/' . $post->image) }}" height="400" width="400" />
      <h1> {{ $post->title }}</h1>
      <p>{{ $post->body }}</p>
      <hr>
      <p>Posted In: {{ $post->category->name }}</p>
    </div>
  </div>

  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <h3 class="comments-title"><span class="glyphicon glyphicon-comment"></span>{{ $post->comments()->count() }} Comments</h3>
      @foreach ($post->comments as $comment)
          <div class="comment">
            <div class="author-info">
              <img src="{{ "https://www.gravatar.com/avatar/". md5(strtolower(trim($comment->email))) . "?s=50&d=mm" }}" class="author-image">
              <div class="author-name">
                  <h4>{{ $comment->name }}</h4>
                  <p class="author-time">{{ date('F nS, Y - g:iA', strtotime($comment->created_at) )}}</p>
              </div>
            </div>

            <div class="comment-content">
              {{ $comment->comment }}
            </div>
          </div>
      @endforeach
    </div>
  </div>

  <div class="row">
    <div id="comment-form" class="col-md-8 col-md-offset-2">
      {{ Form::open(array('route' => array('comments.store', $post->id), 'method' => 'POST')) }}

        <div class="row">
          <div class="col-md-6">
            {{ Form::label('name', 'Name:', array('class' => 'btn-h3-spacing')) }}
            {{ Form::text('name', null, array('class' => 'form-control')) }}
          </div>

          <div class="col-md-6">
            {{ Form::label('email', 'Email:', array('class' => 'btn-h3-spacing')) }}
            {{ Form::text('email', null, array('class' => 'form-control')) }}
          </div>

          <div class="col-md-12">
            {{ Form::label('comment', 'Comment:', array('class' => 'btn-h3-spacing')) }}
            {{ Form::textarea('comment', null, array('class' => 'form-control', 'rows' => '5')) }}
          </div>

          <div class="col-md-4">
            {{ Form::submit('Post Comment', array('class' => 'form-control btn btn-success btn-h3-spacing')) }}
          </div>
      {{ Form::close() }}
    </div>
  </div>
</div>

@endsection
